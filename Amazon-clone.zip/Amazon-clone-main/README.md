# Amazon-clone
This is an Amazon clone using MERN stack.<br>
<br><u>Made as an assignment </u>
<br>Submitted by - Priyanshu Solanki
<br>Submitted to - Karishma Vanwari Ma'am 
<br> Pregrad enrolled course <a href="https://pregrad.in/full-stack-developmentmern/">Full-stack-developmentmern</a>
# screenshot from localhosting
![209748092-c0a53032-7c7d-4a76-bfc8-26735a204a12](https://github.com/scythe2330/Amazon-clone/assets/151831118/8415d593-ee54-4cd2-9f78-0f5b7a71bcff)
<br>
<img width="1440" alt="Screenshot 2024-03-30 at 5 23 14 PM" src="https://github.com/scythe2330/Amazon-clone/assets/151831118/a30acb94-351d-4c72-853d-4dd26bfd4b50">


clone or download the repo then install modules and run frontend and backend using `npm run start`.
